export const About = () => {
    return <h1>About page</h1>;
};