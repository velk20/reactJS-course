# Agenda

1. Class Components
2. Error boundaries
3. Route Guards
4. Resource Guards / isOwner

## Features
 * delete games
 ---
 * latest games
 * search? 

## React optimization
 * react memo
 * useCallback
 * useMemo