# Agenda
1. Unit Testing
2. Deployment
3. Съвети за защитата

4. Lazy loading
5. Search tips

## Features
 * latest games

## React optimization
 * react memo
 * useCallback
 * useMemo

 ## 27.03.23
1. Class Components
2. Error boundaries
3. Route Guards
4. Resource Guards / isOwner
5. delete games


## Backlog
 * search? 